# Project Description:
Exercise for Front End Developer interview to showcase necessary HTML & CSS technology stack and skills.
### Deployment
Landing page is also deployed in Heroku Cloud Environment to AB test for mobile devices.

http://germanesolutions-interview.herokuapp.com/
### Features
- <b>framework.scss</b> : SASS file to compile project style sheet to CSS minified or non minified file.
- <b>custom.css</b> : Outputted compiled SASS CSS file.
- <b>custom.min.css</b> : Outputted minified SASS CSS file